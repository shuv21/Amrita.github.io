/* ==========================================================================
   MILES APART, HEARTS TOGETHER - LUXURY ROMANTIC JAVASCRIPT APP ENGINE
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // --------------------------------------------------------------------------
  // 1. STATE & STORAGE MANAGEMENT
  // --------------------------------------------------------------------------
  function getPastDateISO(days) {
    const d = new Date();
    d.setDate(d.getDate() - days);
    return d.toISOString().slice(0, 10);
  }

  function getFutureDateISO(days) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().slice(0, 16);
  }

  const defaultState = {
    partner1: 'Shiva',
    partner2: 'Amrita',
    city1: 'Delhi, India',
    city2: 'Hapur, India',
    city1Coords: { lat: 28.6139, lng: 77.2090 },
    city2Coords: { lat: 28.7306, lng: 77.7759 },
    distanceKm: 60,
    distanceMiles: 37,
    reunionDate: '2026-08-21T18:00',
    startDate: '2026-11-27',
    customQuote: 'No matter how many miles separate us, my heart will always find you.',
    currentLetterIdx: 0,
    currentTrackIdx: 0,
    isPlaying: false,
    volume: 0.8,
    isMuted: false
  };

  let state = loadState();

  function loadState() {
    try {
      const saved = localStorage.getItem('romantic_app_state');
      if (!saved) return defaultState;
      const parsed = JSON.parse(saved);
      if (!parsed.startDate || parsed.startDate !== '2026-11-27') {
        parsed.startDate = '2026-11-27';
      }
      if (!parsed.partner1 || parsed.partner1 === 'Alex') {
        parsed.partner1 = 'Shiva';
      }
      if (!parsed.partner2 || parsed.partner2 === 'Maya') {
        parsed.partner2 = 'Amrita';
      }
      if (!parsed.reunionDate || !parsed.reunionDate.startsWith('2026-08-21')) {
        parsed.reunionDate = '2026-08-21T18:00';
      }
      return { ...defaultState, ...parsed };
    } catch (e) {
      return defaultState;
    }
  }

  function saveState() {
    try {
      localStorage.setItem('romantic_app_state', JSON.stringify(state));
    } catch (e) {
      console.warn('LocalStorage restricted');
    }
    updateUIFromState();
  }

  // --------------------------------------------------------------------------
  // 2. MEMORIES DATA & REAL VIDEO CALL ENGINE
  // --------------------------------------------------------------------------
  const defaultVideoCallSvg = `data:image/svg+xml;utf8,` + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 960" width="100%" height="100%"><defs><linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#3d2c38"/><stop offset="50%" stop-color="#4a3542"/><stop offset="100%" stop-color="#241923"/></linearGradient><linearGradient id="skinAmrita" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#fdece0"/><stop offset="100%" stop-color="#f5d3bf"/></linearGradient><linearGradient id="skinShiva" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#e2ba99"/><stop offset="100%" stop-color="#ce9e78"/></linearGradient><linearGradient id="blueJacket" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#3b5998"/><stop offset="100%" stop-color="#1e2e4a"/></linearGradient><pattern id="stripes" width="40" height="40" patternUnits="userSpaceOnUse" patternTransform="rotate(5)"><rect width="40" height="20" fill="#1e1e24"/><rect y="20" width="40" height="20" fill="#f8f8fb"/></pattern></defs><rect width="540" height="960" fill="url(#bgGrad)"/><path d="M-60,60 Q120,-40 240,160 Q140,380 -60,260 Z" fill="#b02636" opacity="0.9"/><path d="M-40,80 Q80,0 180,160" stroke="#f2a2ad" stroke-width="5" fill="none" opacity="0.5"/><path d="M-20,130 Q100,50 200,210" stroke="#f2a2ad" stroke-width="3" fill="none" opacity="0.4"/><path d="M100,300 Q270,240 440,300 Q500,480 490,740 Q270,800 50,740 Q40,480 100,300 Z" fill="#1a141a"/><path d="M220,580 Q270,620 320,580 L370,720 Q270,770 170,720 Z" fill="url(#skinAmrita)"/><path d="M40,680 Q270,610 500,680 L540,960 L0,960 Z" fill="url(#stripes)"/><ellipse cx="270" cy="480" rx="145" ry="165" fill="url(#skinAmrita)"/><path d="M125,410 Q270,290 415,410 Q445,530 435,660 Q395,530 375,475 Q270,405 165,475 Q145,530 105,660 Q95,530 125,410 Z" fill="#1f181f"/><g transform="translate(165, 410) scale(1.1)"><ellipse cx="0" cy="0" rx="18" ry="14" fill="#ffffff" stroke="#222" stroke-width="1.8"/><ellipse cx="-10" cy="-10" rx="5" ry="7" fill="#ffffff" stroke="#222" stroke-width="1.8"/><ellipse cx="10" cy="-10" rx="5" ry="7" fill="#ffffff" stroke="#222" stroke-width="1.8"/><circle cx="-5" cy="0" r="2" fill="#111"/><circle cx="5" cy="0" r="2" fill="#111"/><ellipse cx="0" cy="4" rx="2.5" ry="1.8" fill="#ffb703"/><path d="M8,-8 Q14,-14 18,-8 Q14,-2 8,-8 Z" fill="#ff4d88"/><path d="M8,-8 Q14,-14 8,-18 Q2,-14 8,-8 Z" fill="#ff4d88"/><circle cx="8" cy="-8" r="2.5" fill="#ff75a0"/></g><g transform="translate(390, 460) scale(1.1)"><ellipse cx="0" cy="0" rx="18" ry="14" fill="#ffffff" stroke="#222" stroke-width="1.8"/><ellipse cx="-10" cy="-10" rx="5" ry="7" fill="#ffffff" stroke="#222" stroke-width="1.8"/><ellipse cx="10" cy="-10" rx="5" ry="7" fill="#ffffff" stroke="#222" stroke-width="1.8"/><circle cx="-5" cy="0" r="2" fill="#111"/><circle cx="5" cy="0" r="2" fill="#111"/><ellipse cx="0" cy="4" rx="2.5" ry="1.8" fill="#ffb703"/><path d="M8,-8 Q14,-14 18,-8 Q14,-2 8,-8 Z" fill="#ff4d88"/><circle cx="8" cy="-8" r="2.5" fill="#ff75a0"/></g><ellipse cx="210" cy="475" rx="22" ry="11" fill="#ffffff"/><circle cx="212" cy="475" r="7.5" fill="#3a2518"/><circle cx="214" cy="473" r="2" fill="#ffffff"/><ellipse cx="330" cy="475" rx="22" ry="11" fill="#ffffff"/><circle cx="328" cy="475" r="7.5" fill="#3a2518"/><circle cx="326" cy="473" r="2" fill="#ffffff"/><path d="M185,450 Q210,443 235,453" stroke="#3a2518" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M305,453 Q330,443 355,450" stroke="#3a2518" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M270,485 Q278,518 265,523" stroke="#d4a383" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M235,558 Q270,578 305,558 Q270,563 235,558 Z" fill="#e65c7b"/><g transform="translate(340, 660)"><rect width="170" height="250" rx="20" fill="#1b2333" stroke="#ffffff" stroke-width="3"/><clipPath id="insetClip"><rect width="170" height="250" rx="20"/></clipPath><g clip-path="url(#insetClip)"><rect width="170" height="250" fill="#2d3748"/><path d="M20,180 Q85,150 150,180 L170,250 L0,250 Z" fill="url(#blueJacket)"/><path d="M65,160 L85,195 L105,160 Z" fill="#ffffff"/><ellipse cx="85" cy="115" rx="42" ry="48" fill="url(#skinShiva)"/><path d="M40,110 Q85,55 130,110 Q128,75 85,65 Q42,75 40,110 Z" fill="#141118"/><path d="M45,115 Q85,170 125,115 Q120,155 85,160 Q50,155 45,115 Z" fill="#261e20" opacity="0.95"/><circle cx="70" cy="108" r="3.5" fill="#111"/><circle cx="100" cy="108" r="3.5" fill="#111"/><path d="M85,110 L85,125 L89,128" stroke="#b08362" stroke-width="2" fill="none"/><path d="M76,138 Q85,144 94,138" stroke="#8c5840" stroke-width="2.5" fill="none"/></g></g><rect width="540" height="100" fill="linear-gradient(to bottom, rgba(0,0,0,0.7), transparent)"/><text x="30" y="50" fill="#ffffff" font-family="sans-serif" font-size="24" font-weight="bold">Amrita ❤️ Shiva</text><text x="30" y="78" fill="#22c55e" font-family="sans-serif" font-size="16">🟢 HD Video Call • 01:24:18</text></svg>`);

  function getStoredVideoCallImg() {
    try {
      const saved = localStorage.getItem('shiva_amrita_custom_videocall_img');
      if (saved) return saved;
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return defaultVideoCallSvg;
  }

  function saveStoredVideoCallImg(imgUrl) {
    try {
      localStorage.setItem('shiva_amrita_custom_videocall_img', imgUrl);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }

  let activeVideoCallImg = getStoredVideoCallImg();

  const amritaPhotoSvg = `data:image/svg+xml;utf8,` + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 800" width="100%" height="100%"><defs><linearGradient id="bgGrad2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#141018"/><stop offset="50%" stop-color="#241b23"/><stop offset="100%" stop-color="#100b12"/></linearGradient><linearGradient id="skinAmrita2" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stop-color="#fef0e6"/><stop offset="100%" stop-color="#f2cfbb"/></linearGradient><linearGradient id="cyanKurti" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#6cd0db"/><stop offset="50%" stop-color="#4abecb"/><stop offset="100%" stop-color="#34a0ad"/></linearGradient><radialGradient id="softGlow" cx="50%" cy="40%" r="50%"><stop offset="0%" stop-color="#e8a2b5" stop-opacity="0.2"/><stop offset="100%" stop-color="#000000" stop-opacity="0"/></radialGradient></defs><rect width="540" height="800" fill="url(#bgGrad2)"/><rect width="540" height="800" fill="url(#softGlow)"/><path d="M70,220 Q270,120 470,220 Q530,450 510,800 L30,800 Q10,450 70,220 Z" fill="#120e14"/><path d="M40,550 Q270,470 500,550 L540,800 L0,800 Z" fill="url(#cyanKurti)"/><path d="M190,520 L270,680 L350,520 L380,535 L270,720 L160,535 Z" fill="#ffffff" opacity="0.95"/><path d="M210,540 L270,650 L330,540" fill="none" stroke="#4abecb" stroke-width="3"/><path d="M270,550 L230,600 L270,650 L310,600 Z" fill="none" stroke="#ffffff" stroke-width="2"/><path d="M270,580 L250,605 L270,630 L290,605 Z" fill="none" stroke="#4abecb" stroke-width="2"/><path d="M215,410 Q270,460 325,410 L335,540 Q270,580 205,540 Z" fill="url(#skinAmrita2)"/><ellipse cx="270" cy="310" rx="135" ry="155" fill="url(#skinAmrita2)"/><path d="M135,190 Q90,320 80,550 Q75,680 140,800 Q120,600 130,450 Q145,300 180,210 Z" fill="#1c151e"/><path d="M405,190 Q450,320 460,550 Q465,680 400,800 Q420,600 410,450 Q395,300 360,210 Z" fill="#1c151e"/><path d="M150,170 Q270,110 390,170 Q430,240 420,380 Q390,260 360,210 Q270,160 180,210 Q150,260 120,380 Q110,240 150,170 Z" fill="#241b27"/><ellipse cx="205" cy="300" rx="20" ry="11" fill="#ffffff"/><circle cx="207" cy="300" r="7.5" fill="#2d1c16"/><circle cx="209" cy="298" r="2.5" fill="#ffffff"/><ellipse cx="335" cy="300" rx="20" ry="11" fill="#ffffff"/><circle cx="333" cy="300" r="7.5" fill="#2d1c16"/><circle cx="331" cy="298" r="2.5" fill="#ffffff"/><path d="M180,278 Q205,270 230,280" stroke="#221712" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M310,280 Q335,270 360,278" stroke="#221712" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M270,305 Q276,335 264,340" stroke="#d99f82" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M238,370 Q270,385 302,370 Q270,375 238,370 Z" fill="#e85b7e"/><path d="M242,370 Q270,363 298,370" stroke="#c43d5f" stroke-width="1.5" fill="none"/><path d="M270,225 C265,215 250,215 250,228 C250,240 270,250 270,252 C270,250 290,240 290,228 C290,215 275,215 270,225 Z" fill="#ff4d79"/><g transform="translate(180, 340) scale(0.7)"><ellipse cx="0" cy="0" rx="20" ry="16" fill="#ffe0bd" stroke="#111" stroke-width="2"/><ellipse cx="-12" cy="0" rx="8" ry="10" fill="#ffe0bd" stroke="#111" stroke-width="2"/><circle cx="-5" cy="-2" r="2" fill="#000"/><circle cx="5" cy="-2" r="2" fill="#000"/><path d="M-8,-8 Q0,-12 8,-8" stroke="#000" stroke-width="3" fill="none"/><path d="M-5,4 Q0,10 5,4" fill="#ff4d6d" stroke="#111" stroke-width="1"/></g><g transform="translate(360, 340) scale(0.7)"><ellipse cx="0" cy="0" rx="20" ry="16" fill="#ffe0bd" stroke="#111" stroke-width="2"/><ellipse cx="12" cy="0" rx="8" ry="10" fill="#ffe0bd" stroke="#111" stroke-width="2"/><circle cx="-5" cy="-2" r="2" fill="#000"/><circle cx="5" cy="-2" r="2" fill="#000"/><path d="M-8,-8 Q0,-12 8,-8" stroke="#000" stroke-width="3" fill="none"/><path d="M-5,4 Q0,10 5,4" fill="#ff4d6d" stroke="#111" stroke-width="1"/></g><g transform="translate(270, 410) scale(0.6)"><ellipse cx="0" cy="0" rx="20" ry="16" fill="#ffe0bd" stroke="#111" stroke-width="2"/><circle cx="-5" cy="-2" r="2" fill="#000"/><circle cx="5" cy="-2" r="2" fill="#000"/><path d="M-5,4 Q0,10 5,4" fill="#ff4d6d" stroke="#111" stroke-width="1"/></g><rect width="540" height="60" fill="linear-gradient(to bottom, rgba(0,0,0,0.6), transparent)"/><text x="20" y="38" fill="#ffffff" font-family="sans-serif" font-size="20" font-weight="bold">Amrita ❤️ (30 July 2026)</text></svg>`);

  const defaultMemories = [
    {
      id: 1,
      title: 'My Love Amrita ❤️',
      date: '2026-07-30',
      category: 'my_love',
      img: amritaPhotoSvg,
      desc: 'Amrita in her gorgeous cyan kurti with white lace & cute face filter stickers! My endless love for Amrita ❤️',
      likes: 52,
      rotation: -2
    },
    {
      id: 3,
      title: '3 AM Video Call Smiles ❤️',
      date: '2026-07-16',
      category: 'calls',
      img: activeVideoCallImg,
      desc: 'Amrita lying down with cute Hello Kitty hair clips & Shiva on the video call! Every video call with you makes my entire world shine bright.',
      likes: 31,
      rotation: 0,
      isVideoCallPhoto: true
    }
  ];

  let memories = [...defaultMemories];

  // --------------------------------------------------------------------------
  // 3. LOVE LETTERS DATA
  // --------------------------------------------------------------------------
  const letters = [
    {
      title: "To My Soulmate, When You Miss Me...",
      date: "August 01, 2026",
      body: `My dearest love,\n\nWhenever the miles feel heavy and you wish I was beside you, please close your eyes and place your hand over your heart. That heartbeat you feel is synchronized with mine.\n\nEvery morning I wake up, the first thought in my mind is your smile. Distance is just a test to see how far love can travel, and ours spans the entire universe.\n\nI love you more than words can ever capture.`
    },
    {
      title: "Open When You Can't Sleep At Night...",
      date: "August 01, 2026",
      body: `Hey gorgeous,\n\nI know it's late and the room is quiet. I wish I was there to wrap my arms around you, pull the blanket over us, and whisper soft sweet nothings until you fall asleep.\n\nLook up out your window at the moon. I'm looking at the very same moon right now, sending you a warm bear hug across the night sky. Sleep peacefully, my sweet love.`
    },
    {
      title: "Open On A Rainy Afternoon...",
      date: "August 01, 2026",
      body: `My favorite human,\n\nAs raindrops hit your window, imagine us sitting in a cozy café with two steaming mugs of coffee. No places to rush to, no flight schedules to worry about—just you and me laughing together.\n\nRain always reminds me that after every storm comes the brightest rainbow. Our reunion rainbow is coming very soon!`
    },
    {
      title: "Open On Our Special Anniversary...",
      date: "August 01, 2026",
      body: `My forever love,\n\nHappy Anniversary! Looking back at where we started and how far we've come fills my heart with so much pride and gratitude.\n\nThank you for choosing me every single day. Thank you for your patience, your kindness, and your unconditional warmth. Here's to forever with you!`
    }
  ];

  // --------------------------------------------------------------------------
  // 4. REASONS I LOVE YOU DATA
  // --------------------------------------------------------------------------
  const reasonsData = [
    { num: '01', icon: '💖', title: 'Your Infectious Laugh', desc: 'The way your whole face lights up whenever you laugh makes my heart melt instantly.' },
    { num: '02', icon: '☀️', title: 'Good Morning Texts', desc: 'Sending me sweet morning notes so I wake up feeling loved every single day.' },
    { num: '03', icon: '🎧', title: 'Our Shared Playlist', desc: 'How we listen to the exact same songs together while thousands of miles apart.' },
    { num: '04', icon: '📞', title: '3 AM Video Calls', desc: 'Staying up late just to hear about my day, even when you have an early morning.' },
    { num: '05', icon: '🌟', title: 'Unwavering Support', desc: 'You believe in my dreams even when I doubt myself. You are my biggest anchor.' },
    { num: '06', icon: '🤗', title: 'Your Soft Warm Hugs', desc: 'The feeling of melting into your arms at the airport gate after months apart.' },
    { num: '07', icon: '🍕', title: 'Foodie Adventures', desc: 'Planning every single meal we will eat together on our next upcoming visit.' },
    { num: '08', icon: '🌙', title: 'Looking At Same Moon', desc: 'Knowing that under the same night sky, we are sharing the exact same view.' },
    { num: '09', icon: '💌', title: 'Handwritten Notes', desc: 'The thoughtful letters you hide in my luggage before I board my flight home.' },
    { num: '10', icon: '👑', title: 'Your Kindness', desc: 'The pure, gentle way you treat everyone around you with so much respect.' },
    { num: '11', icon: '🚀', title: 'Our Future Dreams', desc: 'Talking about our future home, cozy living room, and never having to say goodbye.' },
    { num: '12', icon: '♾️', title: 'Simply Being You', desc: 'Because out of 8 billion people on Earth, my heart picked you forever.' }
  ];

  // --------------------------------------------------------------------------
  // 5. CHAT MESSAGES DATA
  // --------------------------------------------------------------------------
  let chatMessages = [
    { sender: 'them', text: 'Good morning my love! ❤️ How did you sleep?', time: '08:30 AM', read: true },
    { sender: 'me', text: 'Morning sweetie! Woke up thinking about you 🥰', time: '08:32 AM', read: true },
    { sender: 'them', text: 'Guess what? Counting down to August 21, 2026 for our reunion! ✈️', time: '08:35 AM', read: true },
    { sender: 'me', text: 'I am counting down every single minute! I miss holding your hand so much.', time: '08:36 AM', read: true },
    { sender: 'them', text: 'Me too... but distance is temporary, and we are forever! Sending you a big warm hug! 🤗❤️', time: '08:40 AM', read: true }
  ];

  // --------------------------------------------------------------------------
  // 6. INITIAL UI SYNC
  // --------------------------------------------------------------------------
  function updateUIFromState() {
    document.getElementById('brand-title').textContent = `${state.partner1} & ${state.partner2}`;
    document.getElementById('footer-couple-names').textContent = `${state.partner1} & ${state.partner2}`;
    document.getElementById('chat-partner-name').textContent = `My Love ${state.partner2}`;

    const sealInitials = document.getElementById('seal-initials');
    if (sealInitials) {
      const p1Init = state.partner1 ? state.partner1.charAt(0).toUpperCase() : 'S';
      const p2Init = state.partner2 ? state.partner2.charAt(0).toUpperCase() : 'A';
      sealInitials.textContent = `${p1Init} & ${p2Init}`;
    }

    const songArtist = document.getElementById('song-artist');
    if (songArtist) {
      songArtist.textContent = `${state.partner1} & ${state.partner2}'s Theme • Ambient Acoustic Piano`;
    }

    document.getElementById('city-1-label').textContent = state.city1;
    document.getElementById('city-2-label').textContent = state.city2;

    const distKm = state.distanceKm || (state.city1.toLowerCase().includes('delhi') && state.city2.toLowerCase().includes('hapur') ? 60 : 60);
    const distMiles = state.distanceMiles || Math.round(distKm * 0.621371);

    const heroDist = document.getElementById('hero-stat-distance');
    if (heroDist) {
      heroDist.textContent = `${distKm.toLocaleString()} Km`;
    }

    const distNumText = document.getElementById('distance-number-text');
    if (distNumText) {
      distNumText.textContent = `${distKm.toLocaleString()} Km / ${distMiles.toLocaleString()} Miles`;
    }

    document.getElementById('input-partner1').value = state.partner1;
    document.getElementById('input-partner2').value = state.partner2;
    document.getElementById('input-city1').value = state.city1;
    document.getElementById('input-city2').value = state.city2;
    document.getElementById('input-reunion-date').value = state.reunionDate;
    document.getElementById('input-start-date').value = state.startDate;
    document.getElementById('input-custom-quote').value = state.customQuote;

    const targetDateObj = new Date(state.reunionDate);
    document.getElementById('target-reunion-display').textContent = targetDateObj.toLocaleDateString('en-US', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    calculateDaysTogether();
  }

  function calculateDaysTogether() {
    const start = new Date(state.startDate);
    const now = new Date();
    const diffTime = Math.abs(now - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    document.getElementById('hero-stat-together').textContent = diffDays.toLocaleString();
    document.getElementById('milestone-text').textContent = `We have been loving each other for ${diffDays.toLocaleString()} days and counting!`;
  }

  updateUIFromState();

  // --------------------------------------------------------------------------
  // 7. BACKGROUND CANVAS ENGINE (STARS, CLOUDS, FIREFLIES, HEARTS)
  // --------------------------------------------------------------------------
  const canvas = document.getElementById('sky-canvas');
  const ctx = canvas.getContext('2d');

  let width = canvas.width = window.innerWidth;
  let height = canvas.height = window.innerHeight;

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  const stars = [];
  const fireflies = [];
  const floatingHearts = [];

  // Create Stars
  for (let i = 0; i < 180; i++) {
    stars.push({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 1.5 + 0.5,
      alpha: Math.random(),
      speed: Math.random() * 0.02 + 0.005
    });
  }

  // Create Fireflies
  for (let i = 0; i < 25; i++) {
    fireflies.push({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 2 + 1,
      angle: Math.random() * Math.PI * 2,
      speed: Math.random() * 0.5 + 0.2,
      alpha: Math.random()
    });
  }

  // Floating Hearts
  function spawnFloatingHeart() {
    if (floatingHearts.length < 15) {
      floatingHearts.push({
        x: Math.random() * width,
        y: height + 20,
        size: Math.random() * 14 + 10,
        speedY: Math.random() * 0.8 + 0.3,
        speedX: (Math.random() - 0.5) * 0.4,
        alpha: Math.random() * 0.5 + 0.3
      });
    }
  }

  setInterval(spawnFloatingHeart, 1200);

  function renderSky() {
    ctx.clearRect(0, 0, width, height);

    // Draw Stars
    stars.forEach(star => {
      star.alpha += star.speed;
      if (star.alpha > 1 || star.alpha < 0.2) star.speed = -star.speed;
      ctx.fillStyle = `rgba(255, 255, 255, ${star.alpha})`;
      ctx.beginPath();
      ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw Fireflies
    fireflies.forEach(f => {
      f.angle += 0.02;
      f.x += Math.cos(f.angle) * f.speed;
      f.y += Math.sin(f.angle) * f.speed;

      if (f.x < 0) f.x = width;
      if (f.x > width) f.x = 0;
      if (f.y < 0) f.y = height;
      if (f.y > height) f.y = 0;

      ctx.fillStyle = `rgba(255, 126, 179, ${Math.abs(Math.sin(f.angle)) * 0.8 + 0.2})`;
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#FF4D88';
      ctx.beginPath();
      ctx.arc(f.x, f.y, f.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });

    // Draw Floating Hearts
    for (let i = floatingHearts.length - 1; i >= 0; i--) {
      const h = floatingHearts[i];
      h.y -= h.speedY;
      h.x += h.speedX;

      ctx.fillStyle = `rgba(255, 77, 136, ${h.alpha})`;
      ctx.font = `${h.size}px sans-serif`;
      ctx.fillText('❤️', h.x, h.y);

      if (h.y < -30) {
        floatingHearts.splice(i, 1);
      }
    }

    requestAnimationFrame(renderSky);
  }

  renderSky();

  // --------------------------------------------------------------------------
  // 8. PAGE 2: WORLD MAP CANVAS & BEZIER HEART PATH
  // --------------------------------------------------------------------------
  const mapCanvas = document.getElementById('world-map-canvas');
  const mapCtx = mapCanvas.getContext('2d');

  function resizeMap() {
    if (mapCanvas && mapCanvas.parentElement) {
      mapCanvas.width = mapCanvas.parentElement.clientWidth;
      mapCanvas.height = mapCanvas.parentElement.clientHeight;
    }
  }

  resizeMap();
  window.addEventListener('resize', resizeMap);

  let heartProgress = 0;

  function drawWorldMap() {
    if (!mapCanvas) return;
    const w = mapCanvas.width;
    const h = mapCanvas.height;

    mapCtx.clearRect(0, 0, w, h);

    // Draw subtle grid map lines
    mapCtx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    mapCtx.lineWidth = 1;

    for (let x = 0; x < w; x += 40) {
      mapCtx.beginPath();
      mapCtx.moveTo(x, 0);
      mapCtx.lineTo(x, h);
      mapCtx.stroke();
    }
    for (let y = 0; y < h; y += 40) {
      mapCtx.beginPath();
      mapCtx.moveTo(0, y);
      mapCtx.lineTo(w, y);
      mapCtx.stroke();
    }

    // Two City Nodes Coords
    const p1 = { x: w * 0.28, y: h * 0.45 };
    const p2 = { x: w * 0.72, y: h * 0.42 };
    const cp = { x: w * 0.5, y: h * 0.15 }; // Control point for curved Bezier arch

    // Draw Arc Curve Line
    mapCtx.beginPath();
    mapCtx.moveTo(p1.x, p1.y);
    mapCtx.quadraticCurveTo(cp.x, cp.y, p2.x, p2.y);
    mapCtx.strokeStyle = 'rgba(255, 77, 136, 0.6)';
    mapCtx.lineWidth = 3;
    mapCtx.setLineDash([8, 8]);
    mapCtx.shadowBlur = 15;
    mapCtx.shadowColor = '#FF4D88';
    mapCtx.stroke();
    mapCtx.setLineDash([]);
    mapCtx.shadowBlur = 0;

    // Draw City Nodes
    [p1, p2].forEach((p, idx) => {
      mapCtx.beginPath();
      mapCtx.arc(p.x, p.y, 8, 0, Math.PI * 2);
      mapCtx.fillStyle = '#FF4D88';
      mapCtx.shadowBlur = 12;
      mapCtx.shadowColor = '#FF4D88';
      mapCtx.fill();
      mapCtx.shadowBlur = 0;

      // Pulse ring
      mapCtx.beginPath();
      mapCtx.arc(p.x, p.y, 16 + Math.sin(Date.now() * 0.005) * 6, 0, Math.PI * 2);
      mapCtx.strokeStyle = 'rgba(255, 126, 179, 0.4)';
      mapCtx.lineWidth = 1.5;
      mapCtx.stroke();
    });

    // Calculate Heart Position along Bezier
    heartProgress += 0.004;
    if (heartProgress > 1) heartProgress = 0;

    const t = heartProgress;
    const hx = (1 - t) * (1 - t) * p1.x + 2 * (1 - t) * t * cp.x + t * t * p2.x;
    const hy = (1 - t) * (1 - t) * p1.y + 2 * (1 - t) * t * cp.y + t * t * p2.y;

    // Draw Traveling Heart
    mapCtx.font = '22px sans-serif';
    mapCtx.shadowBlur = 15;
    mapCtx.shadowColor = '#FF4D88';
    mapCtx.fillText('❤️', hx - 11, hy + 8);
    mapCtx.shadowBlur = 0;

    requestAnimationFrame(drawWorldMap);
  }

  drawWorldMap();

  // Map Click Pulse Interaction
  const mapContainer = document.getElementById('map-container');
  if (mapContainer) {
    mapContainer.addEventListener('click', (e) => {
      const rect = mapContainer.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      showToast(`💖 Sending a wave of love to ${state.partner2}!`);
      createHeartExplosion(x, y, mapContainer);
    });
  }

  function createHeartExplosion(x, y, container) {
    for (let i = 0; i < 8; i++) {
      const particle = document.createElement('span');
      particle.textContent = '❤️';
      particle.style.position = 'absolute';
      particle.style.left = `${x}px`;
      particle.style.top = `${y}px`;
      particle.style.fontSize = `${Math.random() * 16 + 12}px`;
      particle.style.pointerEvents = 'none';
      particle.style.transition = 'all 0.8s ease-out';
      container.appendChild(particle);

      setTimeout(() => {
        const dx = (Math.random() - 0.5) * 120;
        const dy = (Math.random() - 0.5) * 120;
        particle.style.transform = `translate(${dx}px, ${dy}px) scale(0)`;
        particle.style.opacity = '0';
      }, 20);

      setTimeout(() => particle.remove(), 900);
    }
  }

  // --------------------------------------------------------------------------
  // 9. PAGE 3: COUNTDOWN TIMER ENGINE
  // --------------------------------------------------------------------------
  function updateCountdown() {
    const target = new Date(state.reunionDate).getTime();
    const now = new Date().getTime();
    const diff = target - now;

    if (diff <= 0) {
      document.getElementById('count-days').textContent = '00';
      document.getElementById('count-hours').textContent = '00';
      document.getElementById('count-minutes').textContent = '00';
      document.getElementById('count-seconds').textContent = '00';
      document.getElementById('hero-stat-days').textContent = 'REUNITED!';
      return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    document.getElementById('count-days').textContent = days < 10 ? `0${days}` : days;
    document.getElementById('count-hours').textContent = hours < 10 ? `0${hours}` : hours;
    document.getElementById('count-minutes').textContent = minutes < 10 ? `0${minutes}` : minutes;
    document.getElementById('count-seconds').textContent = seconds < 10 ? `0${seconds}` : seconds;

    document.getElementById('hero-stat-days').textContent = `${days} Days`;
  }

  setInterval(updateCountdown, 1000);
  updateCountdown();

  // Add to Calendar
  document.getElementById('btn-add-calendar').addEventListener('click', () => {
    const startDateISO = new Date(state.reunionDate).toISOString().replace(/-|:|\.\d\d\d/g, "");
    const title = encodeURIComponent(`Reunion with ${state.partner2} ❤️`);
    const details = encodeURIComponent(`Our long awaited reunion date! Distance = 0!`);
    const gcalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startDateISO}/${startDateISO}&details=${details}`;
    window.open(gcalUrl, '_blank');
  });

  // --------------------------------------------------------------------------
  // 10. PAGE 4: MEMORIES POLAROID GALLERY
  // --------------------------------------------------------------------------
  const polaroidGrid = document.getElementById('polaroid-grid');

  function renderMemories(filter = 'all') {
    polaroidGrid.innerHTML = '';

    const filtered = filter === 'all' ? memories : memories.filter(m => m.category === filter);

    filtered.forEach(m => {
      const card = document.createElement('div');
      card.className = 'polaroid-card';
      card.style.setProperty('--rotation', `${m.rotation || 0}deg`);

      card.innerHTML = `
        <div class="polaroid-img-wrapper">
          <img src="${m.img}" alt="${m.title}" loading="lazy" />
        </div>
        <div class="polaroid-caption">
          <div class="polaroid-title">${m.title}</div>
          <div class="polaroid-date">${m.date}</div>
        </div>
      `;

      // 3D Tilt Effect
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.04)`;
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = `rotate(${m.rotation || 0}deg)`;
      });

      card.addEventListener('click', () => openLightbox(m));

      polaroidGrid.appendChild(card);
    });
  }

  renderMemories();

  // Memory Filter Buttons
  const filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderMemories(btn.dataset.filter);
    });
  });

  // Lightbox Modal & Photo Uploader
  const modalLightbox = document.getElementById('modal-lightbox');
  const btnUploadLightboxPhoto = document.getElementById('btn-upload-lightbox-photo');
  const lightboxFileInput = document.getElementById('lightbox-file-input');
  let currentLightboxItem = null;

  function openLightbox(item) {
    currentLightboxItem = item;
    document.getElementById('lightbox-img').src = item.img;
    document.getElementById('lightbox-title') ? document.getElementById('lightbox-title').textContent = item.title : null;
    document.getElementById('lightbox-caption').textContent = item.title;
    document.getElementById('lightbox-date').textContent = item.date;
    document.getElementById('lightbox-desc').textContent = item.desc;
    document.getElementById('memory-like-count').textContent = item.likes;
    modalLightbox.classList.add('active');
  }

  if (btnUploadLightboxPhoto && lightboxFileInput) {
    btnUploadLightboxPhoto.addEventListener('click', () => {
      lightboxFileInput.click();
    });

    lightboxFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target.result;
        if (currentLightboxItem) {
          currentLightboxItem.img = dataUrl;
          document.getElementById('lightbox-img').src = dataUrl;
          
          if (currentLightboxItem.isVideoCallPhoto || currentLightboxItem.id === 3) {
            activeVideoCallImg = dataUrl;
            saveStoredVideoCallImg(dataUrl);
            const mainVImg = document.getElementById('videocall-main-img');
            if (mainVImg) mainVImg.src = dataUrl;
          }
          renderMemories();
          showToast('📸 Photo Updated Successfully!');
        }
      };
      reader.readAsDataURL(file);
    });
  }

  document.getElementById('btn-close-lightbox').addEventListener('click', () => {
    modalLightbox.classList.remove('active');
  });

  document.getElementById('btn-like-memory').addEventListener('click', () => {
    if (currentLightboxItem) {
      currentLightboxItem.likes += 1;
      document.getElementById('memory-like-count').textContent = currentLightboxItem.likes;
      showToast('❤️ Memory Liked!');
    }
  });

  // Add Memory Modal with Local File Upload
  const modalAddMemory = document.getElementById('modal-add-memory');
  const btnUploadMemoryFile = document.getElementById('btn-upload-memory-file');
  const memoryFileInput = document.getElementById('memory-file-input');
  const memoryFileName = document.getElementById('memory-file-name');
  let uploadedMemoryDataUrl = '';

  if (btnUploadMemoryFile && memoryFileInput) {
    btnUploadMemoryFile.addEventListener('click', () => memoryFileInput.click());
    memoryFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        uploadedMemoryDataUrl = evt.target.result;
        if (memoryFileName) memoryFileName.textContent = `✅ Loaded: ${file.name}`;
        showToast(`📁 Loaded Photo: "${file.name}"`);
      };
      reader.readAsDataURL(file);
    });
  }

  document.getElementById('btn-add-memory').addEventListener('click', () => {
    modalAddMemory.classList.add('active');
  });
  document.getElementById('btn-close-add-memory').addEventListener('click', () => {
    modalAddMemory.classList.remove('active');
  });

  document.getElementById('form-add-memory').addEventListener('submit', (e) => {
    e.preventDefault();
    const inputUrl = document.getElementById('memory-img-url').value;
    const finalImg = uploadedMemoryDataUrl || inputUrl || 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&w=800&q=80';

    const newMem = {
      id: Date.now(),
      title: document.getElementById('memory-title').value,
      img: finalImg,
      date: document.getElementById('memory-date').value,
      category: document.getElementById('memory-category').value,
      desc: document.getElementById('memory-desc').value,
      likes: 1,
      rotation: (Math.random() - 0.5) * 6
    };
    memories.unshift(newMem);
    renderMemories();
    modalAddMemory.classList.remove('active');
    showToast('📸 New Memory Saved!');
    document.getElementById('form-add-memory').reset();
    uploadedMemoryDataUrl = '';
    if (memoryFileName) memoryFileName.textContent = '';
  });

  // REAL VIDEO CALL MODAL CONTROLLER
  const modalVideocall = document.getElementById('modal-videocall');
  const btnOpenVideocall = document.getElementById('btn-open-videocall');
  const btnChatVideocall = document.getElementById('btn-chat-videocall');
  const btnCloseVideocall = document.getElementById('btn-close-videocall');
  const videocallMainImg = document.getElementById('videocall-main-img');
  const btnVUpload = document.getElementById('btn-v-upload');
  const videocallFileInput = document.getElementById('videocall-file-input');
  const btnVHeart = document.getElementById('btn-v-heart');
  const btnVMute = document.getElementById('btn-v-mute');
  const btnVCamera = document.getElementById('btn-v-camera');
  const btnVEnd = document.getElementById('btn-v-end');
  const videocallHeartsLayer = document.getElementById('videocall-hearts-layer');
  const videocallTimerElem = document.getElementById('videocall-timer');

  let callSeconds = 5058; // 01:24:18 default
  let callTimerInterval = null;

  function updateCallTimerDisplay() {
    callSeconds++;
    const hrs = Math.floor(callSeconds / 3600).toString().padStart(2, '0');
    const mins = Math.floor((callSeconds % 3600) / 60).toString().padStart(2, '0');
    const secs = (callSeconds % 60).toString().padStart(2, '0');
    if (videocallTimerElem) videocallTimerElem.textContent = `${hrs}:${mins}:${secs}`;
  }

  function openVideoCallModal() {
    if (videocallMainImg) {
      videocallMainImg.src = activeVideoCallImg;
    }
    if (modalVideocall) {
      modalVideocall.classList.add('active');
    }
    if (!callTimerInterval) {
      callTimerInterval = setInterval(updateCallTimerDisplay, 1000);
    }
    showToast(`📹 Video Call Connected with ${state.partner2} ❤️`);
  }

  if (btnOpenVideocall) btnOpenVideocall.addEventListener('click', openVideoCallModal);
  if (btnChatVideocall) btnChatVideocall.addEventListener('click', openVideoCallModal);

  if (btnCloseVideocall) {
    btnCloseVideocall.addEventListener('click', () => {
      if (modalVideocall) modalVideocall.classList.remove('active');
    });
  }

  if (btnVEnd) {
    btnVEnd.addEventListener('click', () => {
      if (modalVideocall) modalVideocall.classList.remove('active');
      showToast('📞 Video Call Ended. "I love you!"');
    });
  }

  if (btnVMute) {
    let isMuted = false;
    btnVMute.addEventListener('click', () => {
      isMuted = !isMuted;
      btnVMute.style.background = isMuted ? '#ef4444' : 'rgba(255,255,255,0.15)';
      showToast(isMuted ? '🔇 Microphone Muted' : '🎙️ Microphone Unmuted');
    });
  }

  if (btnVCamera) {
    let camOff = false;
    btnVCamera.addEventListener('click', () => {
      camOff = !camOff;
      btnVCamera.style.background = camOff ? '#ef4444' : 'rgba(255,255,255,0.15)';
      showToast(camOff ? '📷 Camera Off' : '📷 Camera On');
    });
  }

  if (btnVUpload && videocallFileInput) {
    btnVUpload.addEventListener('click', () => videocallFileInput.click());

    videocallFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (evt) => {
        const dataUrl = evt.target.result;
        activeVideoCallImg = dataUrl;
        saveStoredVideoCallImg(dataUrl);

        if (videocallMainImg) videocallMainImg.src = dataUrl;

        // Update memory card #3 in gallery
        const vnMem = memories.find(m => m.id === 3 || m.isVideoCallPhoto);
        if (vnMem) {
          vnMem.img = dataUrl;
          renderMemories();
        }

        showToast(`📸 Video Call Photo Updated: "${file.name}"!`);
      };

      reader.readAsDataURL(file);
    });
  }

  if (btnVHeart && videocallHeartsLayer) {
    btnVHeart.addEventListener('click', () => {
      for (let i = 0; i < 6; i++) {
        const h = document.createElement('span');
        h.textContent = ['💖', '❤️', '💕', '🥰', '✨'][Math.floor(Math.random() * 5)];
        h.style.position = 'absolute';
        h.style.left = `${Math.random() * 80 + 10}%`;
        h.style.bottom = '80px';
        h.style.fontSize = `${Math.random() * 20 + 20}px`;
        h.style.transition = 'all 1.2s ease-out';
        h.style.pointerEvents = 'none';
        videocallHeartsLayer.appendChild(h);

        setTimeout(() => {
          h.style.transform = `translateY(-${Math.random() * 250 + 150}px) scale(1.4)`;
          h.style.opacity = '0';
        }, 30);

        setTimeout(() => h.remove(), 1300);
      }
      showToast('💖 Sent Waves of Floating Hearts!');
    });
  }

  // --------------------------------------------------------------------------
  // 11. PAGE 5: LOVE LETTERS & TYPEWRITER ENGINE
  // --------------------------------------------------------------------------
  const envelopeCard = document.getElementById('envelope-card');
  const waxSeal = document.getElementById('wax-seal');
  const letterBodyText = document.getElementById('letter-body-text');

  let typewriterTimeout = null;

  function loadLetter(idx) {
    if (typewriterTimeout) clearTimeout(typewriterTimeout);

    state.currentLetterIdx = idx;
    const l = letters[idx] || letters[0];

    document.getElementById('letter-title').textContent = l.title;
    document.getElementById('letter-date').textContent = l.date;
    document.querySelector('.partner-name-sig').textContent = `${state.partner1} ❤️`;

    // Reset typewriter text
    letterBodyText.textContent = '';
    let i = 0;
    const speed = 25;

    function typeWriter() {
      if (i < l.body.length) {
        letterBodyText.textContent += l.body.charAt(i);
        i++;
        typewriterTimeout = setTimeout(typeWriter, speed);
      }
    }

    if (envelopeCard.classList.contains('open')) {
      typeWriter();
    }
  }

  waxSeal.addEventListener('click', () => {
    envelopeCard.classList.toggle('open');
    if (envelopeCard.classList.contains('open')) {
      loadLetter(state.currentLetterIdx);
      showToast('💌 Envelope Opened!');
    }
  });

  document.getElementById('btn-next-letter').addEventListener('click', () => {
    state.currentLetterIdx = (state.currentLetterIdx + 1) % letters.length;
    updateLetterTabs();
    if (envelopeCard.classList.contains('open')) {
      loadLetter(state.currentLetterIdx);
    } else {
      envelopeCard.classList.add('open');
      loadLetter(state.currentLetterIdx);
    }
  });

  document.getElementById('btn-replay-letter').addEventListener('click', () => {
    if (envelopeCard.classList.contains('open')) {
      loadLetter(state.currentLetterIdx);
    }
  });

  const letterTabs = document.querySelectorAll('.letter-tab-btn[data-letter]');
  letterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const idx = parseInt(tab.dataset.letter, 10);
      state.currentLetterIdx = idx;
      updateLetterTabs();
      envelopeCard.classList.add('open');
      loadLetter(idx);
    });
  });

  function updateLetterTabs() {
    letterTabs.forEach((tab, i) => {
      if (i === state.currentLetterIdx) tab.classList.add('active');
      else tab.classList.remove('active');
    });
  }

  // Write Custom Letter Modal
  const modalCustomLetter = document.getElementById('modal-custom-letter');
  document.getElementById('btn-write-letter-tab').addEventListener('click', () => {
    modalCustomLetter.classList.add('active');
  });
  document.getElementById('btn-close-custom-letter').addEventListener('click', () => {
    modalCustomLetter.classList.remove('active');
  });

  document.getElementById('form-custom-letter').addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('custom-letter-title').value;
    const body = document.getElementById('custom-letter-text').value;

    letters.push({
      title: title,
      date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      body: body
    });

    state.currentLetterIdx = letters.length - 1;
    modalCustomLetter.classList.remove('active');
    envelopeCard.classList.add('open');
    loadLetter(state.currentLetterIdx);
    showToast('💌 Your Custom Letter Added!');
    document.getElementById('form-custom-letter').reset();
  });

  // --------------------------------------------------------------------------
  // 12. PAGE 6: 12 REASONS I LOVE YOU GRID
  // --------------------------------------------------------------------------
  const reasonsGrid = document.getElementById('reasons-grid');

  function renderReasons() {
    reasonsGrid.innerHTML = '';
    reasonsData.forEach(r => {
      const card = document.createElement('div');
      card.className = 'reason-card glass-card';
      card.innerHTML = `
        <div class="reason-number">${r.num}</div>
        <div>
          <div class="reason-icon">${r.icon}</div>
          <h3 class="reason-title">${r.title}</h3>
          <p class="reason-desc">${r.desc}</p>
        </div>
        <div class="reason-flip-hint">Click to send heart ❤️</div>
      `;

      card.addEventListener('click', (e) => {
        createHeartExplosion(e.clientX, e.clientY, document.body);
        showToast(`💖 Reason #${r.num}: ${r.title}`);
      });

      reasonsGrid.appendChild(card);
    });
  }

  renderReasons();

  // --------------------------------------------------------------------------
  // 13. PAGE 7: OUR SONG MUSIC PLAYER (CUSTOM AUDIO PLAYER)
  // --------------------------------------------------------------------------
  let audioCtx = null;
  let synthInterval = null;
  let htmlAudio = null;

  const hindiPlaylist = [];
  let currentTrackIdx = 0;

  const vinylDisc = document.getElementById('vinyl-disc');
  const btnPlayPause = document.getElementById('btn-play-pause');
  const playPauseIcon = document.getElementById('play-pause-icon');
  const visualizerCanvas = document.getElementById('visualizer-canvas');
  const vizCtx = visualizerCanvas ? visualizerCanvas.getContext('2d') : null;

  function initAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (!htmlAudio) {
      htmlAudio = new Audio();
      htmlAudio.loop = true;
      htmlAudio.volume = state.volume || 0.8;

      htmlAudio.addEventListener('timeupdate', () => {
        if (htmlAudio.duration) {
          const cur = htmlAudio.currentTime;
          const dur = htmlAudio.duration;
          const pct = (cur / dur) * 100;

          const fill = document.getElementById('progress-bar-fill');
          if (fill) fill.style.width = `${pct}%`;

          const thumb = document.getElementById('progress-bar-thumb');
          if (thumb) thumb.style.left = `${pct}%`;

          const curTimeElem = document.getElementById('time-current');
          if (curTimeElem) {
            const mins = Math.floor(cur / 60);
            const secs = Math.floor(cur % 60).toString().padStart(2, '0');
            curTimeElem.textContent = `${mins}:${secs}`;
          }

          const durTimeElem = document.getElementById('time-total');
          if (durTimeElem && !isNaN(dur)) {
            const mins = Math.floor(dur / 60);
            const secs = Math.floor(dur % 60).toString().padStart(2, '0');
            durTimeElem.textContent = `${mins}:${secs}`;
          }
        }
      });
    }
  }

  // Romantic Melodic Synth generator fallback
  function playSynthChord() {
    if (!audioCtx || !state.isPlaying) return;

    const romanticMelodies = [
      [261.63, 329.63, 392.00, 493.88], // C, E, G, B
      [293.66, 369.99, 440.00, 523.25], // D, F#, A, C
      [329.63, 392.00, 493.88, 587.33], // E, G, B, D
      [220.00, 277.18, 329.63, 440.00]  // A, C#, E, A
    ];

    const currentChord = romanticMelodies[Math.floor(Math.random() * romanticMelodies.length)];

    currentChord.forEach(freq => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

      gain.gain.setValueAtTime(0.04 * state.volume, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 3.8);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + 3.8);
    });
  }

  function renderTrackPills() {
    const trackBar = document.getElementById('track-selector-bar');
    if (!trackBar) return;

    if (hindiPlaylist.length === 0) {
      trackBar.innerHTML = '';
      return;
    }

    trackBar.innerHTML = hindiPlaylist.map((track, i) => `
      <button class="track-pill ${i === currentTrackIdx ? 'active' : ''}" data-track="${i}">
        ${track.cover || '🎵'} ${track.title}
      </button>
    `).join('');
  }

  function loadTrack(idx) {
    const titleElem = document.getElementById('song-title');
    const artistElem = document.getElementById('song-artist');
    const albumCoverElem = document.getElementById('album-cover-img');
    const totalTimeElem = document.getElementById('time-total');
    const curTimeElem = document.getElementById('time-current');
    const fill = document.getElementById('progress-bar-fill');
    const thumb = document.getElementById('progress-bar-thumb');

    if (hindiPlaylist.length === 0) {
      if (titleElem) titleElem.textContent = 'No Songs Added';
      if (artistElem) artistElem.textContent = 'Upload an MP3 song file to play your favorite music!';
      if (albumCoverElem) albumCoverElem.innerHTML = `<span>🎵</span>`;
      if (totalTimeElem) totalTimeElem.textContent = '0:00';
      if (curTimeElem) curTimeElem.textContent = '0:00';
      if (fill) fill.style.width = '0%';
      if (thumb) thumb.style.left = '0%';
      if (htmlAudio) htmlAudio.src = '';
      renderTrackPills();
      return;
    }

    currentTrackIdx = (idx + hindiPlaylist.length) % hindiPlaylist.length;
    const track = hindiPlaylist[currentTrackIdx];

    if (titleElem) titleElem.textContent = track.title;
    if (artistElem) artistElem.textContent = track.artist || 'Custom Uploaded Track';
    if (albumCoverElem) albumCoverElem.innerHTML = `<span>${track.cover || '🎵'}</span>`;
    if (totalTimeElem) totalTimeElem.textContent = track.duration || '0:00';

    renderTrackPills();

    if (htmlAudio) {
      htmlAudio.src = track.audioUrl;
      if (state.isPlaying) {
        htmlAudio.play().catch(() => {});
      }
    }
  }

  function togglePlay() {
    initAudio();
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    if (hindiPlaylist.length === 0) {
      showToast('🎵 No songs in playlist. Please click "Upload Song File" to add your song!');
      return;
    }

    state.isPlaying = !state.isPlaying;

    if (!htmlAudio.src || htmlAudio.src === '') {
      loadTrack(currentTrackIdx);
    }

    if (state.isPlaying) {
      if (playPauseIcon) playPauseIcon.textContent = '⏸';
      if (vinylDisc) vinylDisc.classList.add('playing');
      synthInterval = setInterval(playSynthChord, 3000);
      playSynthChord();
      
      htmlAudio.play().catch(e => {
        console.log('Audio autoplay policy caught:', e);
      });

      const currentSongName = hindiPlaylist[currentTrackIdx] ? hindiPlaylist[currentTrackIdx].title : '';
      showToast(`🎶 Playing "${currentSongName}"`);
    } else {
      if (playPauseIcon) playPauseIcon.textContent = '▶';
      if (vinylDisc) vinylDisc.classList.remove('playing');
      if (synthInterval) clearInterval(synthInterval);
      if (htmlAudio) htmlAudio.pause();
    }
  }

  if (btnPlayPause) btnPlayPause.addEventListener('click', togglePlay);
  const btnAudioToggle = document.getElementById('btn-audio-toggle');
  if (btnAudioToggle) btnAudioToggle.addEventListener('click', togglePlay);

  // Previous & Next Track Buttons
  const btnPrevTrack = document.getElementById('btn-prev-track');
  if (btnPrevTrack) {
    btnPrevTrack.addEventListener('click', () => {
      if (hindiPlaylist.length === 0) {
        showToast('🎵 No songs in playlist. Upload a song file to play!');
        return;
      }
      initAudio();
      loadTrack(currentTrackIdx - 1);
      if (state.isPlaying && htmlAudio) {
        htmlAudio.play().catch(() => {});
      }
      showToast(`⏮️ ${hindiPlaylist[currentTrackIdx].title}`);
    });
  }

  const btnNextTrack = document.getElementById('btn-next-track');
  if (btnNextTrack) {
    btnNextTrack.addEventListener('click', () => {
      if (hindiPlaylist.length === 0) {
        showToast('🎵 No songs in playlist. Upload a song file to play!');
        return;
      }
      initAudio();
      loadTrack(currentTrackIdx + 1);
      if (state.isPlaying && htmlAudio) {
        htmlAudio.play().catch(() => {});
      }
      showToast(`⏭️ ${hindiPlaylist[currentTrackIdx].title}`);
    });
  }

  // Playlist Pills click handler
  document.addEventListener('click', (e) => {
    const pill = e.target.closest('.track-pill');
    if (pill) {
      const trackIdx = parseInt(pill.dataset.track, 10);
      if (!isNaN(trackIdx) && trackIdx < hindiPlaylist.length) {
        initAudio();
        loadTrack(trackIdx);
        if (!state.isPlaying) {
          togglePlay();
        } else if (htmlAudio) {
          htmlAudio.play().catch(() => {});
          showToast(`🎵 Now Playing: ${hindiPlaylist[currentTrackIdx].title}`);
        }
      }
    }
  });

  // Volume Slider & Mute
  const volumeSlider = document.getElementById('volume-slider');
  if (volumeSlider) {
    volumeSlider.addEventListener('input', (e) => {
      state.volume = parseFloat(e.target.value);
      if (htmlAudio) htmlAudio.volume = state.volume;
    });
  }

  const btnMute = document.getElementById('btn-mute');
  if (btnMute) {
    btnMute.addEventListener('click', () => {
      if (htmlAudio) {
        htmlAudio.muted = !htmlAudio.muted;
        document.getElementById('volume-icon').textContent = htmlAudio.muted ? '🔇' : '🔊';
        showToast(htmlAudio.muted ? '🔇 Muted' : '🔊 Unmuted');
      }
    });
  }

  // Progress Bar Seek
  const trackContainer = document.getElementById('progress-bar-track');
  if (trackContainer) {
    trackContainer.addEventListener('click', (e) => {
      if (htmlAudio && htmlAudio.duration) {
        const rect = trackContainer.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const pct = clickX / rect.width;
        htmlAudio.currentTime = pct * htmlAudio.duration;
      }
    });
  }

  // Playlist Button toast
  const btnPlaylist = document.getElementById('btn-playlist');
  if (btnPlaylist) {
    btnPlaylist.addEventListener('click', () => {
      if (hindiPlaylist.length === 0) {
        showToast('📜 Playlist is empty. Click "Upload Song File" to add your favorite songs!');
      } else {
        const listStr = hindiPlaylist.map((t, idx) => `${idx + 1}. ${t.title}`).join(', ');
        showToast(`📜 Playlist: ${listStr}`);
      }
    });
  }

  // Upload Custom Song File
  const btnUploadKesariya = document.getElementById('btn-upload-kesariya-audio');
  const kesariyaFileInput = document.getElementById('kesariya-file-input');
  const kesariyaUploadStatus = document.getElementById('kesariya-upload-status');

  if (btnUploadKesariya && kesariyaFileInput) {
    btnUploadKesariya.addEventListener('click', () => kesariyaFileInput.click());

    kesariyaFileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (evt) => {
        const audioDataUrl = evt.target.result;
        const songName = file.name.replace(/\.[^/.]+$/, "");

        const newTrack = {
          title: songName,
          artist: `Uploaded Song • ${state.partner1} & ${state.partner2}`,
          duration: 'Custom MP3',
          cover: '🎵',
          audioUrl: audioDataUrl
        };

        hindiPlaylist.push(newTrack);

        if (kesariyaUploadStatus) {
          kesariyaUploadStatus.textContent = `✅ Loaded Song File: "${file.name}"`;
          kesariyaUploadStatus.style.color = '#4ade80';
        }

        initAudio();
        loadTrack(hindiPlaylist.length - 1);
        if (!state.isPlaying) {
          togglePlay();
        } else if (htmlAudio) {
          htmlAudio.play().catch(() => {});
        }
        showToast(`🎵 Loaded & Playing "${songName}"!`);
      };

      reader.readAsDataURL(file);
    });
  }

  // Visualizer Animation Loop
  function drawVisualizer() {
    if (vizCtx && visualizerCanvas) {
      vizCtx.clearRect(0, 0, visualizerCanvas.width, visualizerCanvas.height);

      const bars = 32;
      const barWidth = visualizerCanvas.width / bars;

      for (let i = 0; i < bars; i++) {
        const barHeight = state.isPlaying
          ? Math.abs(Math.sin(Date.now() * 0.005 + i * 0.2)) * (visualizerCanvas.height * 0.8) + 5
          : 4;

        vizCtx.fillStyle = '#FF4D88';
        vizCtx.fillRect(i * barWidth, visualizerCanvas.height - barHeight, barWidth - 2, barHeight);
      }
    }

    requestAnimationFrame(drawVisualizer);
  }

  loadTrack(0);
  drawVisualizer();

  // --------------------------------------------------------------------------
  // 16. PAGE 9: LOVE QUIZ ENGINE (HOW WELL DO YOU KNOW ME?)
  // --------------------------------------------------------------------------
  const quizQuestionsBank = {
    shiva: [
      {
        question: "What is Shiva's absolute favorite mood-booster when he misses Amrita?",
        category: "Shiva's Secrets",
        options: [
          "Listening to Kesariya on repeat",
          "Watching old recorded video calls",
          "Writing sweet romantic notes",
          "All of the above ❤️"
        ],
        correct: 3,
        explanation: "Every single one of these brings a warm smile to Shiva's face when thinking of Amrita!"
      },
      {
        question: "What time does Shiva love sending sweet messages?",
        category: "Daily Habits",
        options: [
          "11:11 PM (Make a wish time)",
          "12:00 AM Midnight",
          "1:30 AM Late Night",
          "Whenever Amrita is on his mind (all day!)"
        ],
        correct: 3,
        explanation: "Amrita is on Shiva's mind throughout the day, so any moment is the right moment!"
      },
      {
        question: "What is Shiva's dream reunion plan for August 21, 2026?",
        category: "Future Dreams",
        options: [
          "A long warm hug that lasts 10 minutes",
          "A cozy dinner under the moonlight",
          "A romantic drive together",
          "All of these combined!"
        ],
        correct: 3,
        explanation: "August 21, 2026 will be the most special reunion day filled with hugs, dinners, and smiles!"
      },
      {
        question: "What makes Shiva smile instantly on a tiring day?",
        category: "Little Pleasures",
        options: [
          "An unexpected voice note from Amrita",
          "A sweet photo notification",
          "A random 'I love you' text",
          "Any message from Amrita ❤️"
        ],
        correct: 3,
        explanation: "A single notification from Amrita instantly brightens up Shiva's entire day!"
      },
      {
        question: "What is Shiva's favorite nickname for Amrita?",
        category: "Affection",
        options: [
          "My Heart ❤️",
          "Janeman",
          "Sweetheart",
          "Pyaari"
        ],
        correct: 0,
        explanation: "'My Heart' is how Shiva always describes Amrita — because she holds his heart forever."
      },
      {
        question: "Where would Shiva love to travel with Amrita next?",
        category: "Adventures",
        options: [
          "Manali snowy mountains",
          "Goa beach sunset",
          "Paris Eiffel Tower",
          "Anywhere in the world, as long as Amrita is with him"
        ],
        correct: 3,
        explanation: "The destination doesn't matter — being together is the real paradise!"
      }
    ],
    amrita: [
      {
        question: "What is Amrita's favorite romantic gesture from Shiva?",
        category: "Amrita's Favorites",
        options: [
          "Unexpected morning voice notes",
          "Heart-to-heart late night conversations",
          "Cute random check-in messages",
          "All of them ❤️"
        ],
        correct: 3,
        explanation: "Amrita adores every small gesture of love and care from Shiva!"
      },
      {
        question: "How does Amrita react when Shiva sends a cute photo?",
        category: "Sweet Moments",
        options: [
          "Smiles blushingly for minutes",
          "Saves it to her favorite gallery",
          "Replies with heart emojis",
          "All of the above!"
        ],
        correct: 3,
        explanation: "Shiva's photos always bring the sweetest blush to Amrita's face!"
      },
      {
        question: "What is Amrita's favorite comfort mood lifter during distance?",
        category: "Comfort Habits",
        options: [
          "Listening to Kesariya together",
          "Hot Chocolate on a rainy evening",
          "Re-reading sweet letters",
          "Talking to Shiva late at night"
        ],
        correct: 3,
        explanation: "Late-night conversations with Shiva are Amrita's favorite medicine for distance!"
      },
      {
        question: "What is the first thing Amrita wants to do when reunited?",
        category: "Reunion Goals",
        options: [
          "Hold Shiva's hand and never let go",
          "Go for a long peaceful walk",
          "Share a quiet cup of coffee",
          "Give the tightest hug ever ❤️"
        ],
        correct: 3,
        explanation: "That reunion hug is going to be the warmest, tightest, and longest hug ever!"
      },
      {
        question: "What is Amrita's favorite time of the day to talk?",
        category: "Daily Routine",
        options: [
          "Quiet late-night conversations",
          "Early morning check-ins",
          "Afternoon tea break",
          "Anytime Shiva is free"
        ],
        correct: 0,
        explanation: "Late night when the world is quiet is when heart-to-heart talks feel most magical."
      },
      {
        question: "What is Amrita's favorite thing about Shiva?",
        category: "Heart Connection",
        options: [
          "His caring and loving nature",
          "His soothing voice",
          "His smile and jokes",
          "Everything about him ❤️"
        ],
        correct: 3,
        explanation: "Amrita loves everything about Shiva — his heart, his care, and his presence!"
      }
    ],
    couple: [
      {
        question: "What is our special Relationship Start Date?",
        category: "Our Milestones",
        options: [
          "November 27, 2026",
          "February 14, 2023",
          "August 21, 2026",
          "October 15, 2025"
        ],
        correct: 0,
        explanation: "November 27, 2026 is our official, unforgettable relationship start date!"
      },
      {
        question: "What is the reunion target date we are eagerly counting down to?",
        category: "Countdowns",
        options: [
          "August 21, 2026",
          "December 31, 2026",
          "January 1, 2027",
          "October 10, 2026"
        ],
        correct: 0,
        explanation: "August 21, 2026 at 6:00 PM is when our distance comes to an end!"
      },
      {
        question: "What is our featured theme romantic song?",
        category: "Music",
        options: [
          "Kesariya",
          "Tum Hi Ho",
          "Raataan Lambiyan",
          "Tere Hawaale"
        ],
        correct: 0,
        explanation: "Kesariya by Arijit Singh is Shiva & Amrita's ultimate special theme song!"
      },
      {
        question: "What do we both look up at when missing each other at night?",
        category: "Night Sky",
        options: [
          "The Same Moon & Sky 🌕",
          "The Shooting Stars",
          "The City Lights",
          "The Horizon"
        ],
        correct: 0,
        explanation: "No matter how many miles separate us, we look up at the exact same moon every night!"
      },
      {
        question: "What is the distance separating our current cities?",
        category: "Distance",
        options: [
          "60 Km / 37 Miles",
          "120 Km",
          "300 Miles",
          "500 Km"
        ],
        correct: 0,
        explanation: "60 Km / 37 Miles apart, but zero distance between our hearts!"
      },
      {
        question: "What is the secret strength of our long-distance bond?",
        category: "Love Secrets",
        options: [
          "Unshakable trust and daily affection",
          "Sweet voice notes and songs",
          "Late-night conversations",
          "All of the above ❤️"
        ],
        correct: 3,
        explanation: "Trust, communication, and deep love make our bond unbreakable!"
      }
    ]
  };

  let currentQuizMode = 'shiva'; // 'shiva', 'amrita', or 'couple'
  let currentQuestionIdx = 0;
  let quizScore = 0;
  let answeredQuestions = {};

  const quizCardBody = document.getElementById('quiz-card-body');
  const quizResultsCard = document.getElementById('quiz-results-card');
  const questionBadge = document.getElementById('question-badge');
  const questionCategory = document.getElementById('question-category');
  const questionText = document.getElementById('question-text');
  const quizOptionsGrid = document.getElementById('quiz-options-grid');
  const quizFeedbackBox = document.getElementById('quiz-feedback-box');
  const feedbackIcon = document.getElementById('feedback-icon');
  const feedbackHeading = document.getElementById('feedback-heading');
  const feedbackExplanation = document.getElementById('feedback-explanation');
  const btnNextQuestion = document.getElementById('btn-next-question');
  const quizScoreNum = document.getElementById('quiz-score-num');
  const quizTotalNum = document.getElementById('quiz-total-num');
  const quizProgressFill = document.getElementById('quiz-progress-fill');

  function getActiveQuestions() {
    return quizQuestionsBank[currentQuizMode] || quizQuestionsBank.shiva;
  }

  function renderQuestion() {
    const questions = getActiveQuestions();

    if (currentQuestionIdx >= questions.length) {
      showQuizResults();
      return;
    }

    quizCardBody.classList.remove('hidden');
    quizResultsCard.classList.add('hidden');
    quizFeedbackBox.classList.add('hidden');
    btnNextQuestion.classList.add('hidden');

    const q = questions[currentQuestionIdx];

    if (questionBadge) questionBadge.textContent = `QUESTION ${currentQuestionIdx + 1} OF ${questions.length}`;
    if (questionCategory) questionCategory.textContent = q.category || 'Love Quiz';
    if (questionText) questionText.textContent = q.question;
    if (quizScoreNum) quizScoreNum.textContent = quizScore;
    if (quizTotalNum) quizTotalNum.textContent = questions.length;

    const progressPct = ((currentQuestionIdx + 1) / questions.length) * 100;
    if (quizProgressFill) quizProgressFill.style.width = `${progressPct}%`;

    // Render Options
    if (quizOptionsGrid) {
      quizOptionsGrid.innerHTML = '';
      const prefixes = ['A', 'B', 'C', 'D'];

      q.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'quiz-option-btn';
        btn.dataset.index = idx;

        btn.innerHTML = `
          <span class="option-prefix">${prefixes[idx]}</span>
          <span>${opt}</span>
        `;

        btn.addEventListener('click', () => handleOptionSelect(idx));
        quizOptionsGrid.appendChild(btn);
      });
    }
  }

  function handleOptionSelect(selectedIdx) {
    const questions = getActiveQuestions();
    const q = questions[currentQuestionIdx];

    // Disable all options
    const optionBtns = quizOptionsGrid.querySelectorAll('.quiz-option-btn');
    optionBtns.forEach(btn => btn.disabled = true);

    const isCorrect = selectedIdx === q.correct;

    if (isCorrect) {
      quizScore++;
      if (quizScoreNum) quizScoreNum.textContent = quizScore;
      optionBtns[selectedIdx].classList.add('correct');
      if (feedbackIcon) feedbackIcon.textContent = '🎉';
      if (feedbackHeading) feedbackHeading.textContent = 'Spot On! Correct Answer! ❤️';
      triggerConfettiHearts();
      showToast('🎉 Correct Answer! +1 Love Point');
    } else {
      optionBtns[selectedIdx].classList.add('wrong');
      optionBtns[q.correct].classList.add('correct'); // Highlight right answer
      if (feedbackIcon) feedbackIcon.textContent = '💡';
      if (feedbackHeading) feedbackHeading.textContent = 'So Close! Here is the sweet truth:';
    }

    if (feedbackExplanation) feedbackExplanation.textContent = q.explanation;
    quizFeedbackBox.classList.remove('hidden');

    // Show Next or Finish Button
    if (currentQuestionIdx < questions.length - 1) {
      btnNextQuestion.textContent = 'Next Question ➔';
    } else {
      btnNextQuestion.textContent = 'See Final Score & Soulmate Badge 🏆';
    }
    btnNextQuestion.classList.remove('hidden');
  }

  function triggerConfettiHearts() {
    for (let i = 0; i < 8; i++) {
      const heart = document.createElement('div');
      heart.textContent = ['💖', '✨', '💕', '🌹'][Math.floor(Math.random() * 4)];
      heart.style.position = 'fixed';
      heart.style.left = `${Math.random() * 80 + 10}vw`;
      heart.style.top = `${Math.random() * 50 + 20}vh`;
      heart.style.fontSize = `${Math.random() * 1.5 + 1.2}rem`;
      heart.style.zIndex = '9999';
      heart.style.pointerEvents = 'none';
      heart.style.transition = 'all 1.2s ease-out';

      document.body.appendChild(heart);

      setTimeout(() => {
        heart.style.transform = `translateY(-100px) scale(1.5)`;
        heart.style.opacity = '0';
      }, 50);

      setTimeout(() => {
        heart.remove();
      }, 1300);
    }
  }

  function showQuizResults() {
    quizCardBody.classList.add('hidden');
    quizResultsCard.classList.remove('hidden');

    const questions = getActiveQuestions();
    const total = questions.length;
    const pct = Math.round((quizScore / total) * 100);

    const scoreDisplay = document.getElementById('results-score-display');
    const pctDisplay = document.getElementById('results-percentage');
    const badgeTitle = document.getElementById('badge-title');
    const badgeDesc = document.getElementById('badge-desc');

    if (scoreDisplay) scoreDisplay.textContent = `${quizScore} out of ${total}`;
    if (pctDisplay) pctDisplay.textContent = `${pct}%`;

    if (pct === 100) {
      if (badgeTitle) badgeTitle.textContent = '100% Ultimate Soulmates! 👑💕';
      if (badgeDesc) badgeDesc.textContent = 'You know each other\'s hearts inside out! Zero secrets, pure unconditional love!';
    } else if (pct >= 80) {
      if (badgeTitle) badgeTitle.textContent = 'Deeply Connected Hearts! 💖';
      if (badgeDesc) badgeDesc.textContent = 'You know almost everything about each other! A truly beautiful bond!';
    } else {
      if (badgeTitle) badgeTitle.textContent = 'Growing Love & Sweet Discoveries! 🌹';
      if (badgeDesc) badgeDesc.textContent = 'Every question is a chance to learn something new and sweet about your partner!';
    }

    triggerConfettiHearts();
  }

  // Quiz Mode Switches
  document.addEventListener('click', (e) => {
    const modeBtn = e.target.closest('.quiz-mode-pill');
    if (modeBtn) {
      document.querySelectorAll('.quiz-mode-pill').forEach(b => b.classList.remove('active'));
      modeBtn.classList.add('active');

      currentQuizMode = modeBtn.dataset.mode || 'shiva';
      currentQuestionIdx = 0;
      quizScore = 0;
      renderQuestion();

      const modeNames = {
        shiva: "Shiva's Quiz",
        amrita: "Amrita's Quiz",
        couple: "Our Love Story Quiz"
      };
      showToast(`🧩 Started ${modeNames[currentQuizMode]}`);
    }
  });

  if (btnNextQuestion) {
    btnNextQuestion.addEventListener('click', () => {
      currentQuestionIdx++;
      renderQuestion();
    });
  }

  const btnRestartQuiz = document.getElementById('btn-restart-quiz');
  if (btnRestartQuiz) {
    btnRestartQuiz.addEventListener('click', () => {
      currentQuestionIdx = 0;
      quizScore = 0;
      renderQuestion();
      showToast('🔄 Quiz Reset! Good Luck!');
    });
  }

  // Toggle Custom Question Form
  const btnToggleCustomQ = document.getElementById('btn-toggle-custom-q');
  const customQuestionBox = document.getElementById('custom-question-box');

  if (btnToggleCustomQ && customQuestionBox) {
    btnToggleCustomQ.addEventListener('click', () => {
      customQuestionBox.classList.toggle('hidden');
      if (!customQuestionBox.classList.contains('hidden')) {
        customQuestionBox.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }

  // Save Custom Question Handler
  const btnSaveCustomQ = document.getElementById('btn-save-custom-q');
  if (btnSaveCustomQ) {
    btnSaveCustomQ.addEventListener('click', () => {
      const qText = document.getElementById('cq-text').value.trim();
      const opt1 = document.getElementById('cq-opt1').value.trim();
      const opt2 = document.getElementById('cq-opt2').value.trim();
      const opt3 = document.getElementById('cq-opt3').value.trim();
      const opt4 = document.getElementById('cq-opt4').value.trim();
      const story = document.getElementById('cq-story').value.trim();

      if (!qText || !opt1 || !opt2) {
        showToast('⚠️ Please enter a question and at least 2 options!');
        return;
      }

      const options = [opt1, opt2];
      if (opt3) options.push(opt3);
      if (opt4) options.push(opt4);

      quizQuestionsBank[currentQuizMode].push({
        question: qText,
        category: 'Custom Question',
        options: options,
        correct: 0, // Option A is the correct answer
        explanation: story || 'A special custom question created with love!'
      });

      // Clear Inputs
      document.getElementById('cq-text').value = '';
      document.getElementById('cq-opt1').value = '';
      document.getElementById('cq-opt2').value = '';
      document.getElementById('cq-opt3').value = '';
      document.getElementById('cq-opt4').value = '';
      document.getElementById('cq-story').value = '';
      customQuestionBox.classList.add('hidden');

      currentQuestionIdx = 0;
      quizScore = 0;
      renderQuestion();

      showToast('💖 New Question Added To Quiz Successfully!');
    });
  }

  renderQuestion();

  // --------------------------------------------------------------------------
  // 17. PAGE 10: SAME MOON CANVAS & WHISPERS
  // --------------------------------------------------------------------------
  const moonCanvas = document.getElementById('moon-canvas');
  const moonCtx = moonCanvas ? moonCanvas.getContext('2d') : null;

  function drawMoonScene() {
    if (!moonCanvas || !moonCtx) return;
    moonCanvas.width = moonCanvas.parentElement.clientWidth;
    moonCanvas.height = moonCanvas.parentElement.clientHeight;

    const w = moonCanvas.width;
    const h = moonCanvas.height;

    moonCtx.clearRect(0, 0, w, h);

    // Draw Giant Moon
    const moonX = w / 2;
    const moonY = h * 0.35;
    const moonRadius = 60;

    moonCtx.beginPath();
    moonCtx.arc(moonX, moonY, moonRadius, 0, Math.PI * 2);
    moonCtx.fillStyle = '#FFFDF5';
    moonCtx.shadowBlur = 40;
    moonCtx.shadowColor = 'rgba(255, 255, 255, 0.8)';
    moonCtx.fill();
    moonCtx.shadowBlur = 0;

    // Moon Texture Craters
    moonCtx.fillStyle = 'rgba(200, 200, 200, 0.2)';
    moonCtx.beginPath();
    moonCtx.arc(moonX - 15, moonY - 10, 12, 0, Math.PI * 2);
    moonCtx.arc(moonX + 18, moonY + 12, 16, 0, Math.PI * 2);
    moonCtx.arc(moonX - 5, moonY + 20, 10, 0, Math.PI * 2);
    moonCtx.fill();

    // Silhouettes looking up
    moonCtx.fillStyle = '#070B18';
    moonCtx.fillRect(0, h - 30, w, 30); // Hill

    requestAnimationFrame(drawMoonScene);
  }

  drawMoonScene();

  // Send Whisper to Moon
  const btnSendWhisper = document.getElementById('btn-send-whisper');
  if (btnSendWhisper) {
    btnSendWhisper.addEventListener('click', () => {
      const input = document.getElementById('whisper-input');
      const val = input.value.trim();
      if (!val) return;

      document.getElementById('whisper-status').textContent = `✨ Your wish "${val}" was sent to the moon for ${state.partner2}!`;
      input.value = '';
      showToast('✨ Wish Floating To The Moon!');
    });
  }

  // --------------------------------------------------------------------------
  // 17. PAGE 10: CHAT SIMULATOR ENGINE & VOICE MESSAGES
  // --------------------------------------------------------------------------
  const chatBody = document.getElementById('chat-body');
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const typingIndicator = document.getElementById('typing-indicator');

  function renderChat() {
    if (!chatBody) return;
    chatBody.innerHTML = '';
    chatMessages.forEach(msg => {
      const wrapper = document.createElement('div');
      wrapper.className = `chat-bubble-wrapper ${msg.sender === 'me' ? 'sent' : 'received'}`;

      if (msg.isVoice) {
        wrapper.innerHTML = `
          <div class="chat-bubble">
            <div class="chat-voice-bubble">
              <button class="btn-vn-play" data-chat-speech="${msg.speechText || 'I love you'}">▶️</button>
              <div>
                <strong>🎙️ Voice Message</strong>
                <div style="font-size: 0.75rem; opacity: 0.8;">${msg.text}</div>
              </div>
            </div>
            <div class="chat-meta">${msg.time} ${msg.sender === 'me' ? '✓✓' : ''}</div>
          </div>
        `;
      } else {
        wrapper.innerHTML = `
          <div class="chat-bubble">
            ${msg.text}
            <div class="chat-meta">${msg.time} ${msg.sender === 'me' ? '✓✓' : ''}</div>
          </div>
        `;
      }

      chatBody.appendChild(wrapper);
    });

    chatBody.scrollTop = chatBody.scrollHeight;
  }

  renderChat();

  // Chat Play Speech handler
  document.addEventListener('click', (e) => {
    const speechBtn = e.target.closest('[data-chat-speech]');
    if (speechBtn && 'speechSynthesis' in window) {
      const text = speechBtn.dataset.chatSpeech;
      window.speechSynthesis.cancel();
      const utt = new SpeechSynthesisUtterance(text);
      utt.rate = 0.95;
      window.speechSynthesis.speak(utt);
      showToast('🎙️ Playing Chat Voice Message');
    }
  });

  // Chat Mic button event listener
  const btnChatMic = document.getElementById('btn-chat-mic');
  if (btnChatMic) {
    btnChatMic.addEventListener('click', () => {
      const sampleVoiceNoteText = `Aapki bohot yaad aa rahi hai ${state.partner2}... Jaldi aao na! ❤️`;
      chatMessages.push({
        sender: 'me',
        text: 'Voice note (0:08) - "Aapki bohot yaad aa rahi hai..."',
        speechText: sampleVoiceNoteText,
        isVoice: true,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: true
      });

      renderChat();
      showToast('🎙️ Voice Note Sent in Chat!');

      // Auto Response Voice Note Simulation
      setTimeout(() => {
        typingIndicator.classList.add('active');
        document.getElementById('typing-text-label').textContent = `${state.partner2} is recording a voice note...`;
      }, 800);

      setTimeout(() => {
        typingIndicator.classList.remove('active');
        chatMessages.push({
          sender: 'them',
          text: `Voice note (0:12) - "I love you too ${state.partner1}! Hugs!"`,
          speechText: `I love you too ${state.partner1}! Sending you thousands of hugs!`,
          isVoice: true,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          read: true
        });

        renderChat();
        showToast(`🎙️ Voice Message from ${state.partner2}`);
      }, 2600);
    });
  }

  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;

    chatMessages.push({
      sender: 'me',
      text: text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: true
    });

    chatInput.value = '';
    renderChat();

    // Auto Response Simulation
    setTimeout(() => {
      typingIndicator.classList.add('active');
      document.getElementById('typing-text-label').textContent = `${state.partner2} is typing...`;
    }, 600);

    setTimeout(() => {
      typingIndicator.classList.remove('active');
      const replies = [
        `I love you so much ${state.partner1}! ❤️`,
        `Can't wait until I get to hold you in my arms! 🥰`,
        `You are my absolute favorite person in the world! ✨`,
        `Sending you 1,000 warm kisses across the miles! 💋`
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      chatMessages.push({
        sender: 'them',
        text: randomReply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: true
      });

      renderChat();
      showToast(`💬 New Message from ${state.partner2}`);
    }, 2200);
  });

  document.getElementById('btn-chat-heart').addEventListener('click', () => {
    chatInput.value = '❤️ I love you!';
  });

  // --------------------------------------------------------------------------
  // 16. PAGE 10: FOREVER US & LOVE BURST FINALE
  // --------------------------------------------------------------------------
  document.getElementById('btn-love-burst-finale').addEventListener('click', (e) => {
    showToast('🌹 Love Burst Explosion Activated!');
    for (let i = 0; i < 40; i++) {
      setTimeout(() => {
        spawnFloatingHeart();
      }, i * 30);
    }
  });

  document.getElementById('btn-quick-love-burst').addEventListener('click', (e) => {
    createHeartExplosion(e.clientX, e.clientY, document.body);
    showToast('💖 Sparkles Sent!');
  });

  // --------------------------------------------------------------------------
  // 17. PERSONALIZATION MODAL & SETTINGS
  // --------------------------------------------------------------------------
  const modalPersonalize = document.getElementById('modal-personalize');

  document.getElementById('btn-personalize').addEventListener('click', () => {
    modalPersonalize.classList.add('active');
  });

  document.getElementById('btn-close-personalize').addEventListener('click', () => {
    modalPersonalize.classList.remove('active');
  });

  document.getElementById('form-personalize').addEventListener('submit', (e) => {
    e.preventDefault();
    state.partner1 = document.getElementById('input-partner1').value;
    state.partner2 = document.getElementById('input-partner2').value;
    state.city1 = document.getElementById('input-city1').value;
    state.city2 = document.getElementById('input-city2').value;
    state.reunionDate = document.getElementById('input-reunion-date').value;
    state.startDate = document.getElementById('input-start-date').value;
    state.customQuote = document.getElementById('input-custom-quote').value;

    saveState();
    modalPersonalize.classList.remove('active');
    showToast('⚙️ Settings Saved & App Personalized!');
  });

  document.getElementById('btn-reset-personalize').addEventListener('click', () => {
    state = { ...defaultState };
    saveState();
    modalPersonalize.classList.remove('active');
    showToast('🔄 Reset To Defaults!');
  });

  // --------------------------------------------------------------------------
  // 18. CUSTOM GLOW CURSOR & TOASTS
  // --------------------------------------------------------------------------
  const cursorGlow = document.getElementById('cursor-glow');
  const cursorDot = document.getElementById('cursor-dot');

  document.addEventListener('mousemove', (e) => {
    cursorGlow.style.left = `${e.clientX}px`;
    cursorGlow.style.top = `${e.clientY}px`;
    cursorDot.style.left = `${e.clientX}px`;
    cursorDot.style.top = `${e.clientY}px`;
  });

  function showToast(message) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.4s ease';
      setTimeout(() => toast.remove(), 400);
    }, 2800);
  }

  // --------------------------------------------------------------------------
  // 19. SCROLL REVEAL OBSERVER
  // --------------------------------------------------------------------------
  const observerOptions = {
    threshold: 0.15
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, observerOptions);

  document.querySelectorAll('.scroll-reveal').forEach(sec => {
    observer.observe(sec);
  });

  // Mobile Menu Toggle
  const btnMobileMenu = document.getElementById('btn-mobile-menu');
  const navMenu = document.getElementById('nav-menu');

  if (btnMobileMenu && navMenu) {
    btnMobileMenu.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });

    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
      });
    });
  }

});
